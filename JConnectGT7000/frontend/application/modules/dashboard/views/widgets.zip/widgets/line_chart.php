<div class="col-12">
  <label class="form-label text-white">Series</label>
  <div id="linechart-series-list"></div>
 
</div>
